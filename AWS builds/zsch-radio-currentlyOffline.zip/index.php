<!DOCTYPE html>
<meta charset="utf-8"/>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="style/style.css">
  </head>
  <body>
    <div class='title-bar'>
      <img src="img/zschtext.png" />
    </div>
    <div class='nav-bar'>
      <a href='index_old.html'>Dynamic YouTube embed (old version)</a>
      <a href='about.html'>about</a>
    </div>
    <div class='container'>

      <!--player-->
      <div class='player-div'>
        <audio controls src="http://3.135.130.105:8000/stream.mp3"></audio>
        <!-- Now playing info -->
        <div class='now playing'>
          <H2>Now playing</H2>
          <p id='nowPlaying'>Currently Offline</p>
        </div>
      </div>

      <!-- Schedule -->
      <div class='schedule'>
        <table>
          <col width = 40%>
          <col width = 60%>
          <tr>
            <th colspan=2><b>Schedule</b></th>
          </tr>
          <tr>
            <td>
              Radio Shows
            </td>
            <td>
              Premieres on Saturday morning-afternoon<br />
            </td>
          </tr>
        </table>
      </div>
    </div>
  </body>
</html>
