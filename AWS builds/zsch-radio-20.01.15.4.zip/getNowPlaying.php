<?php
$Handle = fopen("data.txt", 'w');
echo fread($Handle, filesize("data.txt"));
?>
