A community-based internet radio station for the zsch Discord server

Hosted on AWS using Elastic Beanstalk for PHP server, and an Ubuntu system running the Icecast server.
Songs are hosted locally, streamed on RadioDJ, and casted using SECaster.
