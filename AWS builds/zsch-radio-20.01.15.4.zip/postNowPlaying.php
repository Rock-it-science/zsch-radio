<?php

if ((isset($_POST["xpwd"])) && (isset($_POST["title"]))) {
	$xpwd= stripcslashes($_POST["xpwd"]);
	if ($xpwd== 'changeme') {
    $data = stripcslashes($_POST["title"]);

		$Handle = fopen("data.txt", 'w');
		fwrite($Handle, $data);
		fclose($Handle);
	}
} else {
	echo "Not set";
}

?>
